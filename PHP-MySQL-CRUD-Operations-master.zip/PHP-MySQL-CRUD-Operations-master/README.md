## PHP-MySQL-CRUD-Operations

> Create, Read, Update and Delete operations in PHP and MySQL.

### Project Demo

Live Project URL- [PHP-MySQL-CRUD-Operations](https://live-demo09.000webhostapp.com/)

### Screenshots

![screenshot](screenshots/screenshot_1.png)
![screenshot](screenshots/screenshot_2.png)
![screenshot](screenshots/screenshot_3.png)
![screenshot](screenshots/screenshot_4.png)
