#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
sudo apt-get update -qq
sudo apt remove needrestart -y
sudo add-apt-repository -y ppa:ondrej/php
sudo DEBIAN_FRONTEND=noninteractive sudo apt install -qq -o Dpkg::Options::="--force-confnew" php8.0 libapache2-mod-php8.0 php8.0-fpm libapache2-mod-fcgid php8.0-curl php8.0-dev php8.0-gd php8.0-mbstring php8.0-zip php8.0-mysql php8.0-xml php-mysql -y --allow-downgrades
sudo apt install -qq -o Dpkg::Options::="--force-confnew" software-properties-common apache2 unzip awscli curl net-tools mysql-client -y
mkdir /home/ubuntu/.aws
touch /home/ubuntu/.aws/config
touch /home/ubuntu/.aws/credentials
sed -i '/^\[default\]/a region = us-east-1' /home/ubuntu/.aws/config
cd /var/www/html/
sudo git clone https://github.com/Usman7236/crud.git
sudo chown -R ubuntu:ubuntu /var/www/html
sudo chmod 775 /var/www/html/index.html
cd crud
sudo unzip PHP-MySQL-CRUD-Operations-master.zip
mv PHP-MySQL-CRUD-Operations-master frontend
sudo mv frontend ../
sudo cp /var/www/html/frontend/000-default.conf /etc/apache2/sites-available/
sudo chown -R ubuntu:ubuntu /var/www/html
sudo chmod 775 /var/www/html/index.html
cp /var/www/html/frontend/monitor.sh /home/ubuntu/
cp /var/www/html/frontend/db.sh /home/ubuntu/
hostname > /var/www/html/index.html
cp /var/www/html/index.html /var/www/html/frontend/ip.html
sudo chmod -R 777 /var/www/html/frontend/
sudo systemctl restart apache2
cd /var/www/html/frontend/
echo "*/5 * * * *    /bin/bash /home/ubuntu/monitor.sh" | crontab -
echo "@reboot    /bin/bash /home/ubuntu/db.sh" | crontab -