#!/bin/bash
sudo apt-get update -y
sudo apt install -y software-properties-common apache2 unzip awscli curl net-tools
sudo apt-get install mysql-client -y
sudo apt-get install -y software-properties-common
sudo add-apt-repository -y ppa:ondrej/php
sudo apt-get install -y php8.0 libapache2-mod-php8.0 php8.0-fpm libapache2-mod-fcgid php8.0-curl php8.0-dev php8.0-gd php8.0-mbstring php8.0-zip php8.0-mysql php8.0-xml
sudo apt-get install php-mysql -y
mkdir /home/ubuntu/.aws
touch /home/ubuntu/.aws/config
touch /home/ubuntu/.aws/credentials
sudo sed -i '/^\[default\]/a region = us-east-1' /home/ubuntu/.aws/config
sudo chown -R ubuntu:ubuntu /var/www/html
sudo chmod 775 /var/www/html/index.html
cd /var/www/html/
sudo git clone https://github.com/Usman7236/crud.git
cd crud
sudo unzip PHP-MySQL-CRUD-Operations-master.zip
mv PHP-MySQL-CRUD-Operations-master frontend && mv frontend ../
sudo chown -R ubuntu:ubuntu /var/www/html/frontend
sudo chmod -R 775 /var/www/html
sudo cp /var/www/html/frontend/000-default.conf /etc/apache2/sites-available/
cp /var/www/html/frontend/monitor.sh /home/ubuntu/
hostname > /var/www/html/index.html
cp /var/www/html/index.html /var/www/html/frontend/ip.html
sudo systemctl restart apache2
