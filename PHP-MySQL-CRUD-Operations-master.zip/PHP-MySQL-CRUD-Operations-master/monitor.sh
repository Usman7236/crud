#!/bin/bash

# Function to get instance ID
get_instance_id() {
    curl -s http://169.254.169.254/latest/meta-data/instance-id
}

# Function to get AWS region
get_aws_region() {
    curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/[a-z]$//'
}

# Function to send metric data to CloudWatch
send_metric_data() {
    aws cloudwatch put-metric-data --metric-name $1 --dimensions Instance=$(get_instance_id) --namespace "Custom" --value $2 --region $(get_aws_region)
}

# Function to monitor and send CPU utilization
monitor_cpu() {
    CPU_UTILIZATION=$(top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1}')
    echo "CPU Utilization: $CPU_UTILIZATION%"
    send_metric_data "CPUUtilization" $CPU_UTILIZATION
}

# Function to monitor and send memory usage
monitor_memory() {
    MEMORY_USAGE=$(free -m | awk 'NR==2{printf "%.2f", $3*100/$2 }')
    echo "Memory Usage: $MEMORY_USAGE%"
    send_metric_data "MemoryUsage" $MEMORY_USAGE
}

# Function to monitor and send disk usage in gigabytes
monitor_disk() {
    DISK_USAGE=$(df -h / | awk 'NR==2{print $3}' | sed 's/.$//')
    echo "Disk Usage: $DISK_USAGE GB"
    send_metric_data "DiskUsage" $DISK_USAGE
}

# Function to monitor and send number of processes
monitor_processes() {
    PROCESSES=$(ps aux | wc -l)
    echo "Number of Processes: $PROCESSES"
    send_metric_data "Processes" $PROCESSES
}

# Function to monitor and send network connections
monitor_network() {
    TCP_CONNECTIONS=$(netstat -an | grep -c ESTABLISHED)
    echo "TCP Connections: $TCP_CONNECTIONS"
    send_metric_data "TCPConnections" $TCP_CONNECTIONS
}

# Main function to run monitoring functions
main() {
    monitor_cpu
    monitor_memory
    monitor_disk
    monitor_processes
    monitor_network
}

# Run main function
main
